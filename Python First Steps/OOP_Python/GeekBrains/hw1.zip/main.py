import re


def get_most_used_in_list(input_list):
    most_used = None
    times = 0
    for item in input_list:
        count = input_list.count(item)
        if count > times:
            times = count
            most_used = item
    return most_used, times


# 1. Get text from file.
print('\nTASK 1.')
text = None
try:
    with open('text.txt', 'r', encoding='utf-8') as f:
        text = f.read()
except FileNotFoundError as e:
    print(e)
    text = ''
else:
    print(text)

# 2. Split text to the sentences.
print('\nTASK 2.')
sentences = re.findall(r'(.*?\.)\s', text)
for sentence in sentences:
    print(sentence)

# 3. Find the most used form of the word, consisting of 4 letters or more, in Russian.
print('\nTASK 3.')
words = re.findall(r'[а-яА-ЯёЁ]{4,}', text.lower())
(most_used_word, used_times) = get_most_used_in_list(words)
print(f'Most used word: {most_used_word}. Find {used_times} times.')

# 4. Select all links.
print('\nTASK 4.')
links = re.findall(r'\S*(?:ru|com|org)[^\s.]*', text)
print(links)

# 5. Find the most used domain in links on page.
print('\nTASK 5.')
domains = re.findall(r'\S*(ru|com|org)[^\s.]*', text)
(most_used_domain, used_times) = get_most_used_in_list(domains)
print(f'Most used domain: {most_used_domain}. Find {used_times} times.')

# 6.Replace all strings by «Ссылка отобразится после регистрации».
print('\nTASK 6.')
new_text = re.sub(r'\S*(?:ru|com|org)[^\s\.]*', '«Ссылка отобразится после регистрации»', text)
print(new_text)

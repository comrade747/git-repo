class Sentence:
  content = []

  def show(self):
    result = ''
    for word in self.content:
      result += str(word) + ' '

    print(result)

  
  def show_part(self):
    parts_of_speech = set()
    for word in self.content:
      parts_of_speech.add(word.part())

    print(parts_of_speech)


  def __init__(self, content = content):
    self.content = content
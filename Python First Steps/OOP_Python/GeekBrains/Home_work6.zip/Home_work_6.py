#1. Создайте новые классы Noun (существительное) и Verb (глагол).
#2. Настройте наследование новых классов от класса Word.
#3. Добавьте в новые классы свойство grammar («Грамматические характеристики»).
# Для класса Noun укажите значение по умолчанию «сущ» (сокращение от существительное),
# а для Verb — «гл» (сокращение от глагол). Вспомните про инкапсуляцию и сделайте свойство grammar защищённым.
#4. Исправьте класс Word, чтобы указанный ниже код не вызывал ошибки.
#Подсказка: теперь в нём не нужно хранить части речи.
#words = []
#words.append(Noun("собака"))
#words.append(Verb("ела"))
#words.append(Noun("колбасу"))
#words.append(Noun("кот"))
#По желанию добавьте ещё несколько глаголов и существительных.
#5. Протестируйте работу старого метода show класса Sentence. Если предложения не формируются, исправьте ошибки.
#6. Допишите в классы Noun и Verb метод part. Данный метод должен возвращать строку с полным названием части речи.
#7. Протестируйте работу метода show_part класса Sentence. Исправьте ошибки, чтобы метод работал.
#Подсказка: ранее part был свойством класса Word, а теперь это метод классов Noun и Verb.
#Загрузить файл


import my_Classes

class Noun(my_Classes.Word):
    __grammar="сущ"

    def __init__(self, text):
        self.text=text
        self.part=self.__grammar

    def part1(self):
        return ("существительное")

class Verb(my_Classes.Word):
    __grammar = "гл"

    def __init__(self, text):
        self.text = text
        self.part = self.__grammar

    def part1(self):
        return ("глагол")

class Adjective (my_Classes.Word):
    __grammar = "прил"

    def __init__(self, text):
        self.text = text
        self.part = self.__grammar

    def part1(self):
        return ("прилагательне")



words=[]
words.append(Noun("утро"))
words.append(Verb("идти"))
words.append(Adjective("красивый"))
words.append(Noun("дождь"))

print(words)
for word in words:
    word.show()

content=[0,1,0,2]
first_sent=my_Classes.Sentence(content)

print("ПРЕДЛОЖЕНИЕ ---",first_sent.show(words))
print(first_sent.show_parts(words))

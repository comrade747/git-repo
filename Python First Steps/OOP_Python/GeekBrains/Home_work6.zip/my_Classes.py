class Word:
    text=None
    part=None

    def __init__(self, text, part):
        self.text=text
        self.part=part

    def show(self):
        print(self.text, self.part)


class Sentence:
    content = []

    def __init__(self, content):
        self.content=content

    def show(self, words):
        sent=""
        for i in self.content:
            sent=sent + words[i].text + " "
        return sent

    def show_parts(self, words):
        parts=[]
        for i in self.content:
            parts.append(words[i].part1())
        parts=set(parts)
        return parts


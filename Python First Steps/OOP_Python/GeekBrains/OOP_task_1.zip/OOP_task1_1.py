#1. Получите текст из файла.
#Примечание: Можете взять свой текст или воспользоваться готовым из материалов к уроку.
# Вспомните операции с чтением файлов и не забудьте сохранить текст в переменную по аналогии с видеоуроками.
#2. Разбейте полученные текст на предложения.
#Примечание: Напоминаем, что в русском языке предложения заканчиваются на ., ! или ?.
#3. Найдите слова, состоящие из 4 букв и более. Выведите на экран 10 самых часто используемых слов.
#Пример вывода: [(“привет”, 3), (“люди”, 3), (“город”, 2)].
#4. Отберите все ссылки.
#Примечание: Для поиска воспользуйтесь методом compile, в который вы вставите свой шаблон для поиска ссылок в тексте.
#5. Ссылки на страницы какого домена встречаются чаще всего?
#Напоминаем, что доменное имя — часть ссылки до первого символа «слеш». Например в ссылке вида travel.mail.ru/travel?id=5
# доменным именем является travel.mail.ru.
#Подсчет частоты сделайте по аналогии с заданием 3, но верните только одну самую частую ссылку.
#6. Замените все ссылки на текст «Ссылка отобразится после регистрации».
#-----------------------------------------------------------------------------------------------------------------------

#Файлы:
#"text.txt" - файл с исходным текстом для обработки
#"url-close-text.txt" - файл с исходным текстом в котором URLs заменены на ХХХХХХХХХХХХХХХХХХХХХХ
#"text-split-on-sent.txt" - файл с исходным текстом, разбитым на предложения, в котором URLs заменены на ХХХХХХХХХХХХХХХХХХХХХХ
#"url-list.txt" - файл со списком всех URLs, встретившихся в "text.txt"
#"all-domens-list.txt" - файл со списком всех доменов, встретившихся в "text.txt"
#"words-4-and-more.txt" - файл со списком всех слов содержащих 4 и более букв, встретившихся в "text.txt"
#"words-4-and-more-list.txt" - файл со списком всех слов содержащих 4 и более букв, в формате (слово:кол-во раз в тексте)
# отсортированным по убыванию, встретившихся в "text.txt"
#

import re
import files_work_funcs as fwf
import dict_work as dw

#читаем исходный текст из файла
big_text=fwf.read_text_from_file("text.txt")

big_text=big_text.replace('\n',' ') # убираем знаки переноса стороки т.к они могут мешать при выборе URLs

patterns=[] # создаем список объектов шаблонов по которым будем искать URLs
patterns.append(re.compile("https://"))
patterns.append(re.compile("http://"))
patterns.append(re.compile("[w{3}.]?[\w+.]+\w+\.[\w]{2,3}"))

urls_list=[]  # создаем списсок для шнанения полученных URLs из текста

#перепровряем нашичие наших паттернов для поиска URLs в тексте.
for pattern in patterns:
    while pattern.search(big_text):
        result=pattern.search(big_text)
        if result:
            start_adress=result.start() #получаем индекс начала URLs подходяшего под шаблон
            end_adress=big_text.index(' ',start_adress) #получаем индекс конца URLs подходяшего под шаблон(предпологая, что в URLs не может быть пробела)
            url=big_text[start_adress:end_adress] # получаем URL из текста
            urls_list.append(url) #сохраняем в список URLs
            big_text=big_text.replace(url, ''"XXXXXXXXXXXXXXXXXXXXXX"'',1) #производим земену только первого подходящего под шаблон!!!
                                                                            # URL в тексте (использую XXXXX тк они заметнее)


# сохраняю в файл текст с закрытыми URLs
fwf.write_text_to_file("url-close-text.txt",big_text)

# сохраняю в файл список URLs
fwf.write_list_to_file("url-list.txt",urls_list)

domains_list=[]

# Удаляю все что может стоять перед доменнім именем
#выделяю доменное имя из URL и созраняю в список domains_list
for i in range(len(urls_list)):
    urls_list[i]=urls_list[i].replace("https://", '')
    urls_list[i] = urls_list[i].replace("http://", '')
    url_end=urls_list[i].find("/")
    if url_end>0:
        domains_list.append(urls_list[i][:url_end])
    else:
        domains_list.append(urls_list[i])

# сохраняю в файл список всех полученных доменов
fwf.write_list_to_file("all-domens-list.txt",domains_list)

#Расчитываю количество вхождения элеметнов в список и сортирую новый список по убыванию
sorted_domains=dw.list_count(domains_list)

print("Домен, который встречается чаще всего: {}".format(sorted_domains[:1]))

# Создаю словарь замен, который приводит текст к виду, возможному для применения метода split('.') для разделения на предложения.
replace_dict={'\n':' ',
              '\r':' ',
              '\n\n':' ',
              '\t':' ',
              '!':'.',
              '?':'.',
              '...':'.',
              'англ.':'английский',
              'Комм.':'коментарий'}

# заменяю в тексте ключи из "словаря замен" на значения
for key,val in replace_dict.items():
    big_text=big_text.replace(key,val)


#Делю текст на предложения
sent_list= big_text.split('.')

#Записываю предложения в файл text_sprlit_on_sent.txt
fwf.write_list_to_file("text-split-on-sent.txt",sent_list,'\n\n')

words_4_and_more=re.findall("[а-яА-Яa-zA-Z]{4,}", big_text) #выбрать все слова в которых 4 и более букв
#words_4_and_more=re.findall("\w{4,}", big_text) #выбрать все слова (в том числе цифры) в которых 4 и более букв

#Записываю все отобранные слова в файл words-4-and-more.txt
fwf.write_list_to_file("words-4-and-more.txt",words_4_and_more)

#Расчитываю количество вхождения слов в список и сортирую новый список по убыванию
sorted_words=dw.list_count(words_4_and_more)

#Записываю кортежи формата (слово, кол-во вхождений) в файл words-4-and-more-dict.txt
fwf.write_list_to_file("words-4-and-more-list.txt",sorted_words)

#вывожу первые по чатоте 10 слов
print("10, слов, которые встречается чаще всего: {}".format(sorted_words[:10]))

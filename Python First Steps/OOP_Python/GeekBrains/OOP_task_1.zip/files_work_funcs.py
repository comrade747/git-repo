# Функции работы с файлами

# записываем предлоения (слова) в файл,предварительно удалив все пробелы пред ними
# каждый последующий элемент списка записывается с новой строки(по умолчанию)
def write_list_to_file(file_name,text_list,sep='\n'):
    with open(file_name, 'w', encoding='utf-8') as f:
        for ithem in text_list:
            cetn_to_write = str(ithem).strip() + sep # записываем предлоения (слова) в файл,предварительно удалив все пробелы пред ними
            f.write(cetn_to_write)


#читаем исходный текст из файла
def read_text_from_file(file_name):
    with open(file_name, 'r', encoding='utf-8') as f:
        return f.read()

# сохраняю в текст в файл
def write_text_to_file(file_name, text):
    with open(file_name, 'w', encoding='utf-8') as f: # сохраняю в файл текст с закрытыми URLs
        f.write(text)
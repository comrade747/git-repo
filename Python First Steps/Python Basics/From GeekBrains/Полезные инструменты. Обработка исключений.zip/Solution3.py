# Тема 7. Полезные инструменты. Обработка исключений.
import math
# Задание 3
numbers = [0, 1, -1, 4, 9, - 3, 64, 100, 729, -36, -25, 55, 99]
print('Изначальный список: ', numbers)


def list_of_square(my_list):
    new_list = my_list.copy()
    new_list = [int(math.sqrt(new_list[i])) if new_list[i] >= 0 else new_list[i] for i in range(len(new_list))]
    return new_list


print('Список, где из положительных чисел извлечён квадратный корень: ', list_of_square(numbers))
input()

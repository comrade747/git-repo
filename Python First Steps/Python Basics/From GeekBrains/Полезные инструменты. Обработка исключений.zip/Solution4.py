# Тема 7. Полезные инструменты. Обработка исключений.

# Задание 4


def number_13_exception(number):
    if number == 13:
        raise ValueError
    else:
        return number ** 2


try:
    user_number = int(input('Введите число от 1 до 100: '))
    if 1 <= user_number <= 100:
        print('Ваше число в квадрате: ', number_13_exception(user_number))
    else:
        print('Вы ввели число не в том диапазоне! ')
except ValueError:
    print('НИКОГДА НЕ ВВОДИТЕ ЧИСЛО 13! \nP.S. Я не суеверный, просто так надо :D ')
input()


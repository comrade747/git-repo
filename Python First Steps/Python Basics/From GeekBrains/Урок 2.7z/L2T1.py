# 1: Даны два произвольные списка. Удалите из первого списка элементы присутствующие во втором списке.
#     Примечание. Списки создайте вручную, например так:
# my_list_1 = [2, 5, 8, 2, 12, 12, 4]
# my_list_2 = [2, 7, 12, 3]

heroes1 = ['Batman','Superman','Wonder Woman','Flash','Aquaman','Cyborg','Batman']
heroes2 = ['Batman','Superman']
for element in heroes2:
    while element in heroes1:
        heroes1.remove(element)
print (heroes1)
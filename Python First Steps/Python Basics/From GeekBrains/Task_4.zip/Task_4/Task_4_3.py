#3: Давайте опишем пару сущностей player и enemy через словарь, который будет иметь ключи и значения:
#name - строка полученная от пользователя,
#health = 100,
#damage = 50.
# ### Поэкспериментируйте с значениями урона и жизней по желанию.
# ### Теперь надо создать функцию attack(person1, person2). Примечание: имена аргументов можете указать свои.
# ### Функция в качестве аргумента будет принимать атакующего и атакуемого.
# ### В теле функция должна получить параметр damage атакующего и отнять это количество от health атакуемого.
# Функция должна сама работать со словарями и изменять их значения.

# Вариант 1 функция непосредственно меняет глобальный словарь

player={'name':None, 'health':100, 'damage':15}
enemy={'name':None, 'health':100, 'damage':10}

def attack_glob(attacking, attacked):
    attacked['health']=attacked.get('health')-attacking.get('damage')
    if attacked['health']<0:
        attacked['health']=0

print("Вариант 1, в функции происходит изменение глобального словаря")
player['name']=input("Введите имя игрока:")
enemy['name']=input("Введите имя врага:")

while player['health']>0 and enemy['health']>0:
    print("Состояние {}, здоровье {}".format(player['name'],player['health']))
    print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']),end='\n\n')
    try:
        punch=int(input("Ведите, кто наносит удар. 1 - Игрок, 2- Враг: "))
    except:
        print("Вы ошиблись при вводе, попробуйте еще раз.",end='\n\n')
        continue

    if punch==1:
        attack_glob(player, enemy)

    elif punch==2:
        attack_glob(enemy,player)

    else:
        print("Вы ошиблись при вводе, попробуйте еще раз.",end='\n\n')
        continue

print("Состояние {}, здоровье {}".format(player['name'],player['health']))
print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']),end='\n\n\n')


# Вариант 2 функция непосредственно НЕ меняет глобальный словарь


player1={'name':None, 'health':100, 'damage':15}
enemy1={'name':None, 'health':100, 'damage':10}

def attack_local(attacking, attacked):
    health=attacked.get('health')-attacking.get('damage')
    if health<0:
        health=0
    return health

print("Вариант 2, в функции НЕ происходит изменение глобального словаря")
player1['name']=input("Введите имя игрока:")
enemy1['name']=input("Введите имя врага:")


while player1['health']>0 and enemy1['health']>0:
    print("Состояние {}, здоровье {}".format(player1['name'],player1['health']))
    print("Состояние {}, здоровье {}".format(enemy1['name'],enemy1['health']),end='\n\n')
    try:
        punch=int(input("Ведите, кто наносит удар. 1 - Игрок, 2- Враг: "))
    except:
        print("Вы ошиблись при вводе, попробуйте еще раз.",end='\n\n')
        continue

    if punch==1:
        enemy1['health']=attack_local(player1, enemy1)

    elif punch==2:
        player1['health']=attack_local(enemy1,player1)

    else:
        print("Вы ошиблись при вводе, попробуйте еще раз.",end='\n\n')
        continue

print("Состояние {}, здоровье {}".format(player1['name'],player1['health']))
print("Состояние {}, здоровье {}".format(enemy1['name'],enemy1['health']),end='\n\n\n')

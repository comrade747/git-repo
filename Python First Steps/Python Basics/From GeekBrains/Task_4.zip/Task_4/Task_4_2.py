#2: Создайте функцию, принимающую на вход 3 числа и возвращающую наибольшее из них.


def max_num(one, two, three):
    return max(one,two,three)

res = max_num(1,2,3)
print ("Ответ:", res)
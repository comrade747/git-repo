#3: Давайте опишем пару сущностей player и enemy через словарь, который будет иметь ключи и значения:
#name - строка полученная от пользователя,
#health = 100,
#damage = 50.
# ### Поэкспериментируйте с значениями урона и жизней по желанию.
# ### Теперь надо создать функцию attack(person1, person2). Примечание: имена аргументов можете указать свои.
# ### Функция в качестве аргумента будет принимать атакующего и атакуемого.
# ### В теле функция должна получить параметр damage атакующего и отнять это количество от health атакуемого.
# Функция должна сама работать со словарями и изменять их значения.
#: Давайте усложним предыдущее задание. Измените сущности, добавив новый параметр - armor = 1.2 (величина брони персонажа)
#Теперь надо добавить новую функцию, которая будет вычислять и возвращать полученный урон по формуле damage / armor
#Следовательно, у вас должно быть 2 функции:
#Наносит урон. Это улучшенная версия функции из задачи 3.
#Вычисляет урон по отношению к броне.

# Вариант 1 функция непосредственно меняет глобальный словарь

player={'name':None, 'health':100, 'damage':15, 'armor':1.2}
enemy={'name':None, 'health':100, 'damage':10, 'armor':1.5}

def damage_range(attacking, attacked):
    return attacking['damage']/attacked['armor']


def attack_global(attacking, attacked):
    attacked['health']=round(attacked.get('health')-damage_range(attacking, attacked), 1)
    if attacked['health']<0:
        attacked['health']=0

print("Вариант 1, в функции происходит изменение глобального словаря")
player['name']=input("Введите имя игрока:")
enemy['name']=input("Введите имя врага:")

while player['health']>0 and enemy['health']>0:
    print("Состояние {}, здоровье {}".format(player['name'],player['health']))
    print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']), end='\n\n')
    try:
        punch=int(input("Ведите, кто наносит удар. 1 - Игрок, 2- Враг: "))
    except:
        print("Вы ошиблись при вводе, попробуйте еще раз.", end='\n\n')
        continue

    if punch==1:
        attack_global(player, enemy)

    elif punch==2:
        attack_global(enemy,player)

    else:
        print("Вы ошиблись при вводе, попробуйте еще раз.", end='\n\n')
        continue

print("Состояние {}, здоровье {}".format(player['name'],player['health']))
print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']), end='\n\n\n')


# Вариант 2 функция непосредственно НЕ меняет глобальный словарь



player={'name':None, 'health':100, 'damage':15, 'armor':1.2}
enemy={'name':None, 'health':100, 'damage':10, 'armor':1.5}


def attack_local(attacking, attacked):
    health=round(attacked.get('health')-damage_range(attacking, attacked), 1)
    if health<0:
        health=0
    return health

print("Вариант 2, в функции НЕ происходит изменение глобального словаря")
player['name']=input("Введите имя игрока:")
enemy['name']=input("Введите имя врага:")

while player['health']>0 and enemy['health']>0:
    print("Состояние {}, здоровье {}".format(player['name'],player['health']))
    print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']), end='\n\n')
    try:
        punch=int(input("Ведите, кто наносит удар. 1 - Игрок, 2- Враг: "))
    except:
        print("Вы ошиблись при вводе, попробуйте еще раз.", end='\n\n')
        continue

    if punch==1:
       enemy['health']= attack_local(player, enemy)

    elif punch==2:
        player['health']=attack_local(enemy,player)

    else:
        print("Вы ошиблись при вводе, попробуйте еще раз.", end='\n\n')
        continue

print("Состояние {}, здоровье {}".format(player['name'],player['health']))
print("Состояние {}, здоровье {}".format(enemy['name'],enemy['health']))

import sys
from core import create_file, create_folder, get_list, delete_file, copy_file, change_dir, save_info
from game import choose_number


try:
    command = sys.argv[1]
except IndexError:
    print('не указана команда')
    sys.exit()


if command == 'list':
    get_list()
elif command == 'create_file':
    try:
        name = sys.argv[2]
    except IndexError:
        print('не задано название файла')
    else:
        create_file(name)
elif command == 'create_folder':
    try:
        name = sys.argv[2]
    except IndexError:
        print('не задано название папки')
    else:
        create_folder(name)
elif command == 'delete':
    try:
        name = sys.argv[2]
    except IndexError:
        print('не задано название файла / папки')
    else:
        try:
            delete_file(name)
        except FileNotFoundError:
            print('не удается найти указанный файл')
elif command == 'copy':
    try:
        name = sys.argv[2]
        new_name = sys.argv[3]
    except IndexError:
        print('неверно заданы имена файлов')
    else:
        try:
            copy_file(name, new_name)
        except FileNotFoundError:
            print('не удается найти указанный файл')
elif command == 'change':
    try:
        path = sys.argv[2]
    except IndexError:
        print('укажите путь - полный или имя папки')
    else:
        try:
            change_dir(path)
        except FileNotFoundError:
            print('не удается найти указанную директорию')
elif command == 'help':
    print('list - список файлов и папок')
    print('create_file - создание файла')
    print('create_folder - созданиие папки')
    print('delete - удаление файла или папки')
    print('copy - копирование файла или папки')
    print('change - изменение рабочей директории и список её файлов')
    print('game - игра загадай число')
elif command == 'game':
    choose_number()



import random


def choose_number():
    print('\nЗагадайте число от 1 до 100,')
    print('программа попробует его угадать')
    print('если она угадала, нажмите "="')
    print('если загаданное число больше - нажмите ">"')
    print('если загаданное число меньше - нажмите "<"')
    print('. . . . . . . . . . . . . . . . . ')

    max_num = 100
    min_num = 1
    users_try = random.randint(40, 60)
    answer = input(f'вы загадали число {users_try}? :')
    try_num = 1

    if answer != '>' and answer != '<' and answer != '=':
        answer = input('введен неверный символ, повторите попытку: ')

    while answer != '=':
        if answer == '>':
            min_num = users_try
            #print(f'min nu = {min_num}, max {max_num}')
            users_try = int((max_num - users_try)/2+min_num)
            answer = input(f'вы загадали число {users_try}? ')
            try_num += 1


        if answer == '<':
            max_num = users_try
            #print(f'min nu = {min_num}, max {max_num}')
            users_try = int((users_try-min_num)/2+min_num)
            answer = input(f'вы загадали число {users_try}? ')
            try_num += 1

        if answer != '>' and answer != '<' and answer != '=':
            answer = input('введен неверный символ, повторите попытку: ')

    else:
        print(f'\nУРА ! загадано число {users_try} !')
        print(f'угадано с {try_num} раза')
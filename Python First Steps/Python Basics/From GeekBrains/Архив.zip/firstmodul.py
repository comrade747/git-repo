
#ПЕРВЫЙ ВАРИАНТ


n1 = (input('Введи первое число: '))
n2 = (input('Введи втрое число: '))
n3 = (input('Введи третье число: '))
numbers = [n1, n2, n3]

import random
print(random.choice(numbers))


#ВТОРОЙ ВАРИАНТ, для работы второго варианта закомментируйте первый варинт.



#numbers = [1, 2, 3, 4]

#import random
#print(random.choice(numbers))


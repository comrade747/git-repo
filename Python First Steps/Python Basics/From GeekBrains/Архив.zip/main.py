
import zadanie2
print(zadanie2)

import zadanie1
print(zadanie1)
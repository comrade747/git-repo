from random import randint

def myrandom(mylist_f):
    #print(mylist_f)
    myresult = []
    #print(len(mylist_f))
    mylist_f_len: int = len(mylist_f)
    if mylist_f_len == 0:
        #print('nono')
        myresult = None
    else:
        myresult_i = randint(1, mylist_f_len)
        #print('i= ', myresult_i)
        myresult = mylist_f[myresult_i - 1]
        #print(myresult)
    return(myresult)





mylist = [1, 2, 3, 4]
# раскомментирвоать для тестаппустого списка
#mylist = []
if __name__ == '__main__':
    print('Говорит модуль 2, рандомный элемент из списка это: ', myrandom(mylist))

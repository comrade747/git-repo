print('='*45)
print('Говорит основная программа.')

print('проверим-ка папки dir')
import os
print(os.listdir(os.getcwd()))

import zd1_module1 as mod1

mod1.mymkdir9()

print('-'*45)
print('Говорит основная программа.')
print('проверим-ка....')
print(os.listdir(os.getcwd()))


from zd2_module1 import myrandom

print('-'*45)
print('Говорит основная программа.')
print('Вызываем функцию из модуля 2:')
myrandom_test = [1, 2, 3, 4, 5, 6, 7]
print(myrandom(myrandom_test))
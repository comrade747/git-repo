# import sys
#
# if not __name__ == '__main__':
#     print('not main!!')
#     sys.exit()


import os

def mymkdir9():
    for i in range(1,10):
        new_path = os.path.join(os.getcwd(), 'dir_{}'.format(i))
        if not (os.path.isdir(new_path)):
            os.mkdir(new_path)
        #print(i)
        #print(new_path)
    print('Говорит модуль 1, папки созданны!')


if __name__ == '__main__':
    mymkdir9()

﻿# ==============================================================================
# Основы языка Python. Интерактивный курс 2019/06/07
# Тема 6. Работа с файлами. Кодировки
# Задание 1.
#
# Исполнитель: Евгений Бабарыкин
#
# Создать модуль music_serialize.py. В этом модуле определить словарь для вашей
# любимой музыкальной группы, например:
# my_favourite_group = {
# ‘name’: ‘Г.М.О.’,
# ‘tracks’: [‘Последний месяц осени’, ‘Шапито’],
# ‘Albums’: [{‘name’: ‘Делать панк-рок’,‘year’: 2016},
# {‘name’: ‘Шапито’,‘year’: 2014}]}
#
# С помощью модулей json и pickle сериализовать данный словарь в json и в байты,
# вывести результаты в терминал. Записать результаты в файлы group.json,
# group.pickle соответственно. В файле group.json указать кодировку utf-8.
# ==============================================================================

import pickle
import json

my_favourite_group = {
    'name': 'Г.М.О.',
    'tracks': ['Последний месяц осени', 'Шапито'],
    'Albums': [
        {'name': 'Делать панк-рок','year': 2016},
        {'name': 'Шапито','year': 2014}
    ]
}

# Сериализовали сведения о любимой музыкальной группе в json.
json_data = json.dumps(my_favourite_group)
# Сериализовали сведения о любимой музыкальной группе в байты.
pickle_data = pickle.dumps(my_favourite_group)

# Выводим в консоль.
print(json_data)
print(type(json_data))
print(type(pickle_data))

# Записываем результаты в файл.
# json
with open('group.json', 'w', encoding='utf-8') as f:
    json.dump(my_favourite_group, f)

# pickle
with open('group.pickle', 'wb') as f:
    pickle.dump(my_favourite_group, f)
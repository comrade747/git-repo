# Тема 5. Модули и библиотеки
import os
# Задание 1


def create_dir():
    for i in range(1, 10):
        new_path = os.path.join(os.getcwd(), f'dir_{i}')
        os.mkdir(new_path)


def delete_dir():
    for i in range(1, 10):
        os.rmdir(os.path.join(f'dir_{i}'))


create_dir()
delete_dir()

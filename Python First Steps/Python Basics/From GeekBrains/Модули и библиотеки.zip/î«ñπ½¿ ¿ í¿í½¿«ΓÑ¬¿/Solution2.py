# Тема 5. Модули и библиотеки
import random
# Задание 2


def random_element_from_list(u_l):
    if len(u_l) > 0:
        return random.choice(u_l)
    else:
        return None


user_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print('Первая последовательность: ', user_list)
print('Случайный элемент первой последовательности: ', random_element_from_list(user_list))
user_list2 = []
print('Пустая последовательность: ', user_list2)
print('Случайный элемент пустой последовательности: ', random_element_from_list(user_list2))
input()

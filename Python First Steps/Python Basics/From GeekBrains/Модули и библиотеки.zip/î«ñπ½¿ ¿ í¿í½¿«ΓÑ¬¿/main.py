# Тема 5. Модули и библиотеки
from Solution1 import create_dir, delete_dir
from Solution2 import random_element_from_list
# Задание 3

create_dir()
delete_dir()

user_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print('Первая последовательность: ', user_list)
print('Случайный элемент первой последовательности: ', random_element_from_list(user_list))
user_list2 = []
print('Пустая последовательность: ', user_list2)
print('Случайный элемент пустой последовательности: ', random_element_from_list(user_list2))
input()


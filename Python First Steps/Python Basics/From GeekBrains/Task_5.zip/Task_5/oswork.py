#1: Создайте модуль (модуль - программа на Python, т.е. файл с расширением .py).
# В нем создайте функцию создающую директории от dir_1 до dir_9 в папке из которой запущен данный код.
# Затем создайте вторую функцию удаляющую эти папки. Проверьте работу функций в этом же модуле.

import os


# Функция содает папки в каталоге проекта, имя папок передается в параметр name
# папки создаются с индексами от Start to end.

def mksetofdirs(name, start, end):
    for i in range(start, end+1):
        try:
            os.mkdir("{}_{}".format(name,i))
        except:
            continue

# Функция удаляет папки в каталоге проекта, имя папок передается в параметр name
# папки удаляются с индексами от Start to end.

def rmsetofdirs(name, start, end):
    for i in range(start, end+1):
        try:
            os.rmdir("{}_{}".format(name, i))
        except:
            continue

# Функция содает папки  в каталоге проекта, с именами из списка передается в параметр names

def mklistofdirs(names):
    for i in names:
        try:
            os.mkdir("{}".format(i))
        except:
            continue

# Функция удаляет папки  в каталоге проекта, с именами из списка передается в параметр names

def rmlistofdirs(names):
    for i in names:
        try:
            os.rmdir("{}".format(i))
        except:
            continue


# проверка внури модуля
#dir_name="XX"
#mksetofdirs(dir_name, 1,7)

#dir_list_name=["one","two","three"]
#mklistofdirs(dir_list_name)

#rmsetofdirs(dir_name, 3,5)

#dir_list_name=["one"]
#rmlistofdirs(dir_list_name)
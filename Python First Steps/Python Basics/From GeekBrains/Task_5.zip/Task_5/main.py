#3: Создайте модуль main.py. Из модулей реализованных в заданиях 1 и 2 сделайте импорт в main.py всех функций.
# Вызовите каждую функцию в main.py и проверьте что все работает как надо.

import oswork

# Функция содает папки в каталоге проекта, имя папок передается в параметр name
# папки создаются с индексами от Start to end.
#mksetofdirs(name, start, end)

oswork.mksetofdirs("Test", 1, 10)

# Функция удаляет папки в каталоге проекта, имя папок передается в параметр name
# папки удаляются с индексами от Start to end.
#rmsetofdirs(name, start, end)

oswork.rmsetofdirs("Test", 3, 5)

# Функция содает папки  в каталоге проекта, с именами из списка передается в параметр names
#mklistofdirs(names)

dir_list=["a","b","c","d"]
oswork.mklistofdirs(dir_list)

# Функция удаляет папки  в каталоге проекта, с именами из списка передается в параметр names
#rmlistofdirs(names)

del_list=["a","d"]
oswork.rmlistofdirs(del_list)

import Rand_work

#Функция возвращает случайный элемент списка
#listrand(inplist)

num_list=[1,5,7,4,2,15,25]
print(Rand_work.listrand(num_list))
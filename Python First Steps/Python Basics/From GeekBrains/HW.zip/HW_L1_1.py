number=int(input('Введите число: '))
number=number+2
print(number)
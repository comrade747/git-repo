number=int(input('Введите число:'))
if number>0 and number< 10:
    number=number**2
    print(number)
else:
    print("Число не верно, введите чило больше 0 но меньше 10")
    number=int(input('Введите число: '))
    number = number ** 2
    print(number)

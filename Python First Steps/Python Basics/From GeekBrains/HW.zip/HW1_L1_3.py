name=input('Введите ваше имя: ')
familia=input('Введите вашу фамилию: ')
age=int(input('Введите ваш возраст: '))
ves=int(input('Введите ваш вес: '))
if age<30 and ves>50 and ves <120:
    print(name,familia,',',age,'год,','Вес',ves,' - хорошее состояние')
if age > 30 and age <=40 and (ves<50 or ves>120):
    print(name,familia,',',age,'год,','Вес',ves,' - следует заняться собой')
if age > 40 and (ves<50 or ves>120):
    print(name,familia,',',age,'год,','Вес',ves, ' - следует обратиться к врачу')
if age==30 or age==40 or ves==50 or ves ==120:
    print(name, familia, ',', age, 'год,', 'Вес', ves, ' - Вы не относитесь ни к одной из категорий решайте сами')